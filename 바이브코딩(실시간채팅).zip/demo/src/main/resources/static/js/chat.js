/**
 * 실시간 채팅 클라이언트 (jQuery + STOMP)
 *
 * REST  : 로그인, 방 목록/생성/입장/나가기/방장 기능, 메시지 조회
 * STOMP : 메시지 전송·수신, 읽음, 입력 중, 참여자·방 목록 실시간 갱신
 */
$(function () {

  const STORAGE_KEY = 'chat.user';
  const TYPING_RESEND_MS = 2000;   // 입력 중 신호 재전송 간격
  const TYPING_HIDE_MS = 3000;     // 신호가 끊기면 표시 숨김
  const BASE_TITLE = document.title;

  const state = {
    user: null,                 // {userId, nickname}
    rooms: new Map(),           // roomId → {room, member, unreadCount}
    current: null,              // {id, room}
    members: [],                // 현재 방 멤버 (읽음 위치 포함)
    messages: [],               // 현재 방 메시지 (오래된 순)
    hasMore: false,
    loadingOlder: false,
    roomSubs: [],
    typingUsers: new Map(),     // userId → {nickname, timer}
    typingActive: false,
    lastTypingSent: 0,
    readTimer: null,
    lastReadSent: null,         // "roomId:messageId"
    connectedOnce: false,
    hiddenUnread: 0             // 탭이 안 보일 때 온 메시지 수
  };

  // =================================================================
  // 공통
  // =================================================================
  function me() { return state.user ? state.user.userId : null; }

  function api(method, url, body) {
    return $.ajax({
      url: url,
      method: method,
      contentType: body !== undefined ? 'application/json' : undefined,
      data: body !== undefined ? JSON.stringify(body) : undefined,
      headers: state.user ? { 'X-User-Id': state.user.userId } : {}
    });
  }

  function errorMessage(xhr) {
    return (xhr.responseJSON && xhr.responseJSON.message) || '요청 처리 중 오류가 발생했습니다.';
  }

  function showError(xhr) {
    if (xhr.status === 401) {
      forceLogin('다시 로그인해 주세요.');
      return;
    }
    alert(errorMessage(xhr));
  }

  function loadSavedUser() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)); } catch (e) { return null; }
  }
  function saveUser(user) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(user)); } catch (e) { /* 무시 */ }
  }
  function clearSavedUser() {
    try { localStorage.removeItem(STORAGE_KEY); } catch (e) { /* 무시 */ }
  }

  function isCurrent(roomId) { return state.current !== null && state.current.id === roomId; }

  function timeLabel(dateTime) {           // "yyyy-MM-dd HH:mm:ss" → "HH:mm"
    return dateTime ? dateTime.substring(11, 16) : '';
  }

  function listTimeLabel(dateTime) {       // 오늘이면 HH:mm, 아니면 MM.dd
    if (!dateTime) return '';
    const today = new Date();
    const d = dateTime.substring(0, 10);
    const todayStr = today.getFullYear() + '-' + pad(today.getMonth() + 1) + '-' + pad(today.getDate());
    return d === todayStr ? timeLabel(dateTime) : d.substring(5, 7) + '.' + d.substring(8, 10);
  }

  function dateLabel(dateStr) {            // "yyyy-MM-dd" → "2026년 11월 27일 금요일"
    const p = dateStr.split('-').map(Number);
    const d = new Date(p[0], p[1] - 1, p[2]);
    const days = ['일', '월', '화', '수', '목', '금', '토'];
    return p[0] + '년 ' + p[1] + '월 ' + p[2] + '일 ' + days[d.getDay()] + '요일';
  }

  function pad(n) { return n < 10 ? '0' + n : String(n); }

  // =================================================================
  // STOMP
  // =================================================================
  const stomp = new StompJs.Client({
    brokerURL: (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws',
    reconnectDelay: 3000            // CONN-02: 끊기면 3초마다 재연결
  });

  stomp.onConnect = function () {
    setStatus('online');
    stomp.subscribe('/topic/rooms', function (f) { onRoomListEvent(JSON.parse(f.body)); });
    stomp.subscribe('/user/queue/errors', function (f) { alert(JSON.parse(f.body).message); });

    if (state.connectedOnce) {
      // CONN-03: 재연결 → 목록과 놓친 메시지 보충
      loadRooms();
      if (state.current) {
        subscribeRoom(state.current.id);
        catchUpMessages(state.current.id);
        refreshDetail(state.current.id);
      }
    } else if (state.current) {
      subscribeRoom(state.current.id);
    }
    state.connectedOnce = true;
    updateInputEnabled();
  };

  stomp.onWebSocketClose = function () {
    state.roomSubs = [];
    if (state.user) setStatus(state.connectedOnce ? 'reconnecting' : 'connecting');
    updateInputEnabled();
  };

  stomp.onStompError = function (frame) {
    const message = (frame.headers && frame.headers.message) || '';
    if (message.indexOf('UNAUTHORIZED') >= 0) {
      forceLogin('다시 로그인해 주세요.');
    } else {
      console.error('STOMP 오류', message, frame.body);
    }
  };

  function publish(destination, body) {
    if (!stomp.connected) return false;
    stomp.publish({ destination: destination, body: JSON.stringify(body || {}) });
    return true;
  }

  function setStatus(status) {          // CONN-01
    const labels = { online: '연결됨', connecting: '연결 중', reconnecting: '재연결 중' };
    $('#connection-status').attr('class', 'status ' + status).text(labels[status]);
  }

  // =================================================================
  // 로그인 / 로그아웃 (USR-01~06)
  // =================================================================
  function showLogin(message, nickname) {
    $('#app').prop('hidden', true);
    $('#login-screen').prop('hidden', false);
    $('#login-error').text(message || '').prop('hidden', !message);
    if (nickname) $('#login-nickname').val(nickname);
    $('#login-nickname').trigger('focus');
  }

  function login(nickname, userId) {
    return $.ajax({
      url: '/api/users/login',
      method: 'POST',
      contentType: 'application/json',
      data: JSON.stringify({ userId: userId || null, nickname: nickname })
    });
  }

  function startApp(user) {
    state.user = user;
    saveUser(user);
    $('#my-nickname').text(user.nickname);
    $('#login-screen').prop('hidden', true);
    $('#app').prop('hidden', false);
    setStatus('connecting');
    stomp.connectHeaders = { userId: user.userId };
    stomp.activate();
    loadRooms();
  }

  $('#login-form').on('submit', function (e) {
    e.preventDefault();
    const nickname = $.trim($('#login-nickname').val());
    const saved = loadSavedUser();
    login(nickname, saved ? saved.userId : null)
      .done(startApp)
      .fail(function (xhr) { showLogin(errorMessage(xhr)); });
  });

  // USR-05: 새로고침해도 같은 사용자로 자동 입장
  (function init() {
    const saved = loadSavedUser();
    if (!saved || !saved.userId) {
      showLogin();
      return;
    }
    login(saved.nickname, saved.userId)
      .done(startApp)
      .fail(function (xhr) { showLogin(errorMessage(xhr), saved.nickname); });
  })();

  $('#btn-logout').on('click', function () {
    if (!confirm('로그아웃할까요?')) return;
    const headers = state.user ? { 'X-User-Id': state.user.userId } : {};
    closeRoomView();
    stomp.deactivate();
    $.ajax({ url: '/api/users/logout', method: 'POST', headers: headers });
    resetState();
    clearSavedUser();
    showLogin();
  });

  // USR-07: 닉네임 변경 (같은 userId로 다시 로그인)
  $('#btn-change-nickname').on('click', function () {
    const nickname = $.trim(prompt('새 닉네임 (한글·영문·숫자 2~20자)', state.user.nickname) || '');
    if (!nickname || nickname === state.user.nickname) return;
    login(nickname, state.user.userId)
      .done(function (user) {
        state.user = user;
        saveUser(user);
        $('#my-nickname').text(user.nickname);
      })
      .fail(showError);
  });

  function forceLogin(message) {
    const nickname = state.user ? state.user.nickname : '';
    closeRoomView();
    stomp.deactivate();
    resetState();
    clearSavedUser();
    showLogin(message, nickname);
  }

  function resetState() {
    state.user = null;
    state.rooms.clear();
    state.connectedOnce = false;
    $('#room-list').empty();
  }

  // =================================================================
  // 방 목록 (ROOM-01, 02, MSG-12)
  // =================================================================
  function loadRooms() {
    api('GET', '/api/rooms')
      .done(function (items) {
        state.rooms.clear();
        items.forEach(function (item) { state.rooms.set(item.room.id, item); });
        if (state.current && state.rooms.has(state.current.id)) {
          state.rooms.get(state.current.id).unreadCount = 0;
        }
        renderRooms();
      })
      .fail(showError);
  }

  function activityOf(room) { return room.lastMessageAt || room.createdAt; }

  function renderRooms() {
    const $list = $('#room-list').empty();
    const items = Array.from(state.rooms.values())
      .sort(function (a, b) { return activityOf(b.room) < activityOf(a.room) ? -1 : 1; });

    if (items.length === 0) {
      $list.append($('<li class="empty">').text('아직 채팅방이 없습니다.'));
      return;
    }

    items.forEach(function (item) {
      const room = item.room;
      const $left = $('<div>')
        .append($('<div class="room-name">').text(room.name))
        .append($('<div class="room-meta">').text(
          '참여 ' + room.participantCount + ' · 멤버 ' + room.memberCount + '/' + room.capacity +
          (item.member ? '' : ' · 미참여')));
      const $right = $('<div class="room-right">')
        .append($('<span class="room-meta">').text(listTimeLabel(room.lastMessageAt)));
      if (item.member && item.unreadCount > 0) {
        $right.append($('<span class="badge">').text(item.unreadCount > 99 ? '99+' : item.unreadCount));
      }

      $('<li>')
        .attr('data-id', room.id)
        .toggleClass('active', isCurrent(room.id))
        .append($left, $right)
        .on('click', function () { openRoom(room.id); })
        .appendTo($list);
    });
  }

  function onRoomListEvent(ev) {
    if (ev.type === 'DELETED') {
      state.rooms.delete(ev.roomId);
      renderRooms();
      if (isCurrent(ev.roomId)) exitToEmpty();
      return;
    }

    const room = ev.room;
    const prev = state.rooms.get(ev.roomId);
    const item = prev
      ? { room: room, member: prev.member, unreadCount: prev.unreadCount }
      : { room: room, member: room.ownerId === me(), unreadCount: 0 };

    // 새 대화가 왔고, 내가 멤버이며, 지금 보고 있는 방이 아니면 배지 +1
    const isNewTalk = prev && room.lastMessageId && room.lastMessageId !== prev.room.lastMessageId &&
      room.lastMessageType === 'TALK' && room.lastMessageSenderId !== me();
    if (isNewTalk && item.member && !isCurrent(ev.roomId)) {
      item.unreadCount += 1;
    }

    state.rooms.set(ev.roomId, item);
    renderRooms();
    if (isCurrent(ev.roomId)) {
      state.current.room = room;
      renderRoomHeader();
    }
  }

  $('#room-form').on('submit', function (e) {
    e.preventDefault();
    const name = $.trim($('#room-name-input').val());
    if (!name) return;
    api('POST', '/api/rooms', { name: name })
      .done(function (detail) {
        $('#room-name-input').val('');
        state.rooms.set(detail.room.id, { room: detail.room, member: true, unreadCount: 0 });
        setupRoom(detail);
      })
      .fail(showError);
  });

  // =================================================================
  // 방 입장 / 화면 전환 (ROOM-04, 06)
  // =================================================================
  function openRoom(roomId) {
    if (isCurrent(roomId)) return;
    const item = state.rooms.get(roomId);
    const request = item && item.member
      ? api('GET', '/api/rooms/' + roomId)
      : api('POST', '/api/rooms/' + roomId + '/join');
    request.done(setupRoom).fail(showError);
  }

  function setupRoom(detail) {
    closeRoomView();
    const roomId = detail.room.id;
    state.current = { id: roomId, room: detail.room };
    state.members = detail.members;
    state.messages = [];
    state.hasMore = false;

    const item = state.rooms.get(roomId) || { room: detail.room };
    item.room = detail.room;
    item.member = true;
    item.unreadCount = 0;
    state.rooms.set(roomId, item);
    renderRooms();

    $('#chat-empty').prop('hidden', true);
    $('#chat-room, #member-panel').prop('hidden', false);
    $('#message-list').empty();
    $('#message-input').val('');
    renderRoomHeader();
    renderMembers();
    renderTyping();
    updateInputEnabled();

    // MSG-08: 최근 50건
    api('GET', '/api/rooms/' + roomId + '/messages')
      .done(function (page) {
        if (!isCurrent(roomId)) return;
        mergeMessages(page.messages);
        state.hasMore = page.hasMore;
        renderAllMessages();
        scrollToBottom();
        scheduleRead();
      })
      .fail(showError);

    if (stomp.connected) subscribeRoom(roomId);
    $('#message-input').trigger('focus');
  }

  function subscribeRoom(roomId) {
    unsubscribeRoom();
    const base = '/topic/rooms/' + roomId;
    state.roomSubs.push(
      stomp.subscribe(base + '/messages', function (f) { onMessage(JSON.parse(f.body)); }),
      stomp.subscribe(base + '/members', function (f) { onMembers(roomId, JSON.parse(f.body)); }),
      stomp.subscribe(base + '/typing', function (f) { onTyping(JSON.parse(f.body)); }),
      stomp.subscribe(base + '/events', function (f) { onRoomEvent(roomId, JSON.parse(f.body)); })
    );
    publish('/app/rooms/' + roomId + '/enter');
  }

  function unsubscribeRoom() {
    state.roomSubs.forEach(function (s) { try { s.unsubscribe(); } catch (e) { /* 연결 끊김 */ } });
    state.roomSubs = [];
  }

  function closeRoomView() {
    if (!state.current) return;
    if (state.typingActive) sendTyping(false);
    unsubscribeRoom();
    publish('/app/rooms/exit');
    state.current = null;
    state.members = [];
    state.messages = [];
    state.typingUsers.forEach(function (t) { clearTimeout(t.timer); });
    state.typingUsers.clear();
  }

  function exitToEmpty() {
    closeRoomView();
    $('#chat-room, #member-panel').prop('hidden', true);
    $('#chat-empty').prop('hidden', false);
    renderRooms();
  }

  function refreshDetail(roomId) {
    api('GET', '/api/rooms/' + roomId).done(function (detail) {
      if (!isCurrent(roomId)) return;
      state.current.room = detail.room;
      state.members = detail.members;
      renderRoomHeader();
      renderMembers();
      refreshUnreadMarks();
    });
  }

  function renderRoomHeader() {
    const room = state.current.room;
    const isOwner = room.ownerId === me();
    $('#room-title').text(room.name);
    $('#room-info').text('방장 ' + room.ownerNickname + ' · 참여 ' + room.participantCount +
      '명 · 멤버 ' + room.memberCount + '/' + room.capacity + '명');
    $('.owner-only').prop('hidden', !isOwner);
  }

  function onRoomEvent(roomId, ev) {
    if (!isCurrent(roomId)) return;
    if (ev.type === 'DELETED') {
      alert('채팅방이 삭제되었습니다.');
      state.rooms.delete(roomId);
      exitToEmpty();
    } else if (ev.type === 'KICKED' && ev.userId === me()) {
      const item = state.rooms.get(roomId);
      if (item) { item.member = false; item.unreadCount = 0; }
      alert('방장이 나를 이 방에서 내보냈습니다.');
      exitToEmpty();
    }
  }

  // =================================================================
  // 방장 기능 / 나가기 (ROOM-05, 09~12)
  // =================================================================
  $('#btn-leave').on('click', function () {
    const roomId = state.current.id;
    if (!confirm('이 방에서 나갈까요? 다시 들어오면 새로 입장한 것으로 처리됩니다.')) return;
    api('POST', '/api/rooms/' + roomId + '/leave')
      .done(function () {
        const item = state.rooms.get(roomId);
        if (item) { item.member = false; item.unreadCount = 0; }
        exitToEmpty();
      })
      .fail(showError);
  });

  $('#btn-rename').on('click', function () {
    const name = $.trim(prompt('새 방 이름 (30자 이하)', state.current.room.name) || '');
    if (!name) return;
    api('PATCH', '/api/rooms/' + state.current.id, { name: name }).fail(showError);
  });

  $('#btn-delete').on('click', function () {
    if (!confirm('방을 삭제하면 모든 대화가 지워집니다. 삭제할까요?')) return;
    const roomId = state.current.id;
    api('DELETE', '/api/rooms/' + roomId)
      .done(function () {
        state.rooms.delete(roomId);
        exitToEmpty();
      })
      .fail(showError);
  });

  function kick(member) {
    if (!confirm(member.nickname + '님을 내보낼까요? 이 방에 다시 들어올 수 없습니다.')) return;
    api('POST', '/api/rooms/' + state.current.id + '/kick', { userId: member.userId }).fail(showError);
  }

  function transferOwner(member) {
    if (!confirm(member.nickname + '님에게 방장을 넘길까요?')) return;
    api('POST', '/api/rooms/' + state.current.id + '/owner', { userId: member.userId }).fail(showError);
  }

  // =================================================================
  // 참여자 목록 (ROOM-08)
  // =================================================================
  function onMembers(roomId, members) {
    if (!isCurrent(roomId)) return;
    state.members = members;
    renderMembers();
    refreshUnreadMarks();
  }

  function renderMembers() {
    const $list = $('#member-list').empty();
    const iAmOwner = state.current && state.current.room.ownerId === me();
    const inRoom = state.members.filter(function (m) { return m.inRoom; }).length;
    $('#member-count').text(state.members.length + '명 (참여 중 ' + inRoom + ')');

    state.members.forEach(function (m) {
      const $line = $('<div class="member-line">')
        .append($('<span class="dot">').toggleClass('on', m.inRoom).attr('title', m.inRoom ? '참여 중' : '자리 비움'))
        .append($('<span>').text(m.nickname));
      if (m.owner) $line.append($('<span class="owner-tag">').text('방장'));
      if (m.userId === me()) $line.append($('<span class="me-tag">').text('(나)'));

      const $li = $('<li>').append($line);
      if (iAmOwner && m.userId !== me()) {
        $li.append($('<div class="member-actions">')
          .append($('<button type="button" class="small secondary">').text('방장 넘기기')
            .on('click', function () { transferOwner(m); }))
          .append($('<button type="button" class="small danger">').text('내보내기')
            .on('click', function () { kick(m); })));
      }
      $list.append($li);
    });
  }

  // =================================================================
  // 메시지 표시 (MSG-03~05, 08~11)
  // =================================================================
  function mergeMessages(list) {
    const known = new Set(state.messages.map(function (m) { return m.id; }));
    list.forEach(function (m) { if (!known.has(m.id)) state.messages.push(m); });
    state.messages.sort(function (a, b) { return a.id - b.id; });
  }

  function onMessage(msg) {
    if (!isCurrent(msg.roomId)) return;
    if (state.messages.some(function (m) { return m.id === msg.id; })) return;

    const wasNearBottom = isNearBottom();
    state.messages.push(msg);
    appendMessage(msg);

    if (msg.type === 'TALK' && msg.senderId !== me()) {
      clearTyping(msg.senderId);
      if (document.visibilityState !== 'visible') {
        state.hiddenUnread += 1;
        document.title = '(' + state.hiddenUnread + ') ' + BASE_TITLE;
      }
    }

    if (msg.senderId === me() || wasNearBottom) {
      scrollToBottom();
    } else {
      $('#btn-new-message').prop('hidden', false);   // MSG-11
    }
    scheduleRead();
  }

  function renderAllMessages() {
    const $list = $('#message-list').empty();
    if (!state.hasMore && state.messages.length > 0) {
      $list.append($('<li class="start">').text('처음 대화입니다.'));
    }
    let prevDate = null;
    state.messages.forEach(function (m) {
      const date = m.sentAt.substring(0, 10);
      if (date !== prevDate) {
        $list.append(dateSeparator(date));
        prevDate = date;
      }
      $list.append(messageElement(m));
    });
    refreshUnreadMarks();
  }

  function appendMessage(m) {
    const $list = $('#message-list');
    const prev = state.messages.length > 1 ? state.messages[state.messages.length - 2] : null;
    const date = m.sentAt.substring(0, 10);
    if (!prev || prev.sentAt.substring(0, 10) !== date) {
      $list.append(dateSeparator(date));               // MSG-10
    }
    const $el = messageElement(m);
    $list.append($el);
    updateUnreadMark($el);
  }

  function dateSeparator(date) {
    return $('<li class="date-separator">').append($('<span>').text(dateLabel(date)));
  }

  function messageElement(m) {
    if (m.type === 'SYSTEM') {
      return $('<li class="system">').text(m.content);
    }
    const mine = m.senderId === me();
    const $li = $('<li class="talk">').toggleClass('mine', mine).attr('data-id', m.id);
    if (!mine) $li.append($('<div class="sender">').text(m.senderNickname));
    // .text() 로만 넣어 HTML·스크립트가 실행되지 않게 함 (NFR-01)
    $li.append($('<div class="row">')
      .append($('<div class="bubble">').text(m.content))
      .append($('<div class="meta">')
        .append($('<span class="unread">'))
        .append($('<span class="time">').text(timeLabel(m.sentAt)))));
    return $li;
  }

  // MSG-07: 안 읽은 멤버 수 = 마지막으로 읽은 위치가 이 메시지보다 앞인 멤버 수
  function unreadCountFor(messageId) {
    return state.members.filter(function (m) { return m.lastReadMessageId < messageId; }).length;
  }

  function updateUnreadMark($el) {
    const id = Number($el.attr('data-id'));
    if (!id) return;
    const n = unreadCountFor(id);
    $el.find('.unread').text(n > 0 ? n : '');
  }

  function refreshUnreadMarks() {
    $('#message-list li.talk').each(function () { updateUnreadMark($(this)); });
  }

  // MSG-09: 맨 위로 스크롤하면 이전 50건
  $('#message-list').on('scroll', function () {
    if (this.scrollTop < 40) loadOlder();
    if (isNearBottom()) $('#btn-new-message').prop('hidden', true);
  });

  function loadOlder() {
    if (!state.current || !state.hasMore || state.loadingOlder || state.messages.length === 0) return;
    const roomId = state.current.id;
    state.loadingOlder = true;
    api('GET', '/api/rooms/' + roomId + '/messages?before=' + state.messages[0].id)
      .done(function (page) {
        if (!isCurrent(roomId)) return;
        const el = document.getElementById('message-list');
        const fromBottom = el.scrollHeight - el.scrollTop;
        mergeMessages(page.messages);
        state.hasMore = page.hasMore;
        renderAllMessages();
        el.scrollTop = el.scrollHeight - fromBottom;     // 보던 위치 유지
      })
      .fail(showError)
      .always(function () { state.loadingOlder = false; });
  }

  // CONN-03: 재연결 시 놓친 메시지 보충
  function catchUpMessages(roomId) {
    const last = state.messages.length ? state.messages[state.messages.length - 1].id : null;
    const url = '/api/rooms/' + roomId + '/messages' + (last ? '?after=' + last : '');
    api('GET', url).done(function (page) {
      if (!isCurrent(roomId)) return;
      const wasNearBottom = isNearBottom();
      mergeMessages(page.messages);
      if (!last) state.hasMore = page.hasMore;
      renderAllMessages();
      if (wasNearBottom) scrollToBottom();
      scheduleRead();
    });
  }

  function isNearBottom() {
    const el = document.getElementById('message-list');
    return el.scrollHeight - el.scrollTop - el.clientHeight < 80;
  }

  function scrollToBottom() {
    const el = document.getElementById('message-list');
    el.scrollTop = el.scrollHeight;
    $('#btn-new-message').prop('hidden', true);
  }

  $('#btn-new-message').on('click', scrollToBottom);

  // =================================================================
  // 읽음 처리 (MSG-07: 방 화면이 열려 있고 탭이 보일 때만)
  // =================================================================
  function scheduleRead() {
    clearTimeout(state.readTimer);
    state.readTimer = setTimeout(sendRead, 300);
  }

  function sendRead() {
    if (!state.current || document.visibilityState !== 'visible' || state.messages.length === 0) return;
    const lastId = state.messages[state.messages.length - 1].id;
    const key = state.current.id + ':' + lastId;
    if (state.lastReadSent === key) return;
    if (publish('/app/rooms/' + state.current.id + '/read', { messageId: lastId })) {
      state.lastReadSent = key;
    }
  }

  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'visible') {
      state.hiddenUnread = 0;
      document.title = BASE_TITLE;
      scheduleRead();
    }
  });

  // =================================================================
  // 전송 / 입력 중 (MSG-01, 02, 06)
  // =================================================================
  const $input = $('#message-input');

  $input.on('keydown', function (e) {
    // 한글 조합 중 Enter는 무시, Shift+Enter는 줄바꿈
    if (e.key === 'Enter' && !e.shiftKey && !e.originalEvent.isComposing) {
      e.preventDefault();
      sendMessage();
    }
  });

  $('#message-form').on('submit', function (e) {
    e.preventDefault();
    sendMessage();
  });

  function sendMessage() {
    const content = $.trim($input.val());
    if (!content || !state.current) return;
    if (content.length > 1000) {
      alert('메시지는 1000자까지 보낼 수 있습니다.');
      return;
    }
    if (publish('/app/rooms/' + state.current.id + '/send', { content: content })) {
      $input.val('').trigger('focus');
      if (state.typingActive) sendTyping(false);
    }
  }

  $input.on('input', function () {
    const hasText = $.trim($input.val()).length > 0;
    if (hasText && (!state.typingActive || Date.now() - state.lastTypingSent > TYPING_RESEND_MS)) {
      sendTyping(true);
    } else if (!hasText && state.typingActive) {
      sendTyping(false);
    }
  });

  function sendTyping(typing) {
    if (!state.current) return;
    publish('/app/rooms/' + state.current.id + '/typing', { typing: typing });
    state.typingActive = typing;
    state.lastTypingSent = Date.now();
  }

  function onTyping(ev) {
    if (ev.userId === me()) return;
    clearTyping(ev.userId);
    if (ev.typing) {
      state.typingUsers.set(ev.userId, {
        nickname: ev.nickname,
        timer: setTimeout(function () { clearTyping(ev.userId); }, TYPING_HIDE_MS)
      });
    }
    renderTyping();
  }

  function clearTyping(userId) {
    const t = state.typingUsers.get(userId);
    if (t) {
      clearTimeout(t.timer);
      state.typingUsers.delete(userId);
      renderTyping();
    }
  }

  function renderTyping() {
    const names = Array.from(state.typingUsers.values()).map(function (t) { return t.nickname; });
    let text = '';
    if (names.length === 1) text = names[0] + '님이 입력 중…';
    else if (names.length > 1) text = names[0] + '님 외 ' + (names.length - 1) + '명이 입력 중…';
    $('#typing-indicator').text(text);
  }

  function updateInputEnabled() {
    const enabled = stomp.connected && state.current !== null;
    $('#message-input, #btn-send').prop('disabled', !enabled);
  }
});
