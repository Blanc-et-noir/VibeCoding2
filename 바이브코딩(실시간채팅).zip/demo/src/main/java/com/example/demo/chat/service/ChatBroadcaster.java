package com.example.demo.chat.service;

import com.example.demo.chat.dto.ChatDtos.ErrorMessage;
import com.example.demo.chat.dto.ChatDtos.RoomEvent;
import com.example.demo.chat.dto.ChatDtos.RoomListEvent;
import com.example.demo.chat.dto.ChatDtos.TypingEvent;
import com.example.demo.chat.event.ChatEvents.MessagePosted;
import com.example.demo.chat.event.ChatEvents.PresenceChanged;
import com.example.demo.chat.event.ChatEvents.RoomChanged;
import com.example.demo.chat.event.ChatEvents.RoomCreated;
import com.example.demo.chat.event.ChatEvents.RoomDeleted;
import com.example.demo.chat.event.ChatEvents.UserKicked;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionalEventListener;

/**
 * STOMP 브로드캐스트 담당.
 * DB 변경 이벤트는 커밋된 뒤에(AFTER_COMMIT) 보내서, 화면이 받자마자 조회해도 같은 데이터가 보이게 한다.
 *
 * 토픽
 *  /topic/rooms                     방 목록 변경 (CREATED / UPDATED / DELETED)
 *  /topic/rooms/{id}/messages       메시지
 *  /topic/rooms/{id}/members        참여자 목록 (읽음 위치 포함)
 *  /topic/rooms/{id}/typing         입력 중
 *  /topic/rooms/{id}/events         방 삭제, 강제 퇴장
 *  /user/queue/errors               나에게만 보내는 오류
 */
@Component
public class ChatBroadcaster {

    private final SimpMessagingTemplate template;
    private final ChatQueryService query;

    public ChatBroadcaster(SimpMessagingTemplate template, ChatQueryService query) {
        this.template = template;
        this.query = query;
    }

    @TransactionalEventListener
    @Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = true)
    public void onRoomCreated(RoomCreated event) {
        query.summary(event.roomId()).ifPresent(summary ->
                template.convertAndSend("/topic/rooms", new RoomListEvent("CREATED", event.roomId(), summary)));
    }

    @TransactionalEventListener
    @Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = true)
    public void onRoomChanged(RoomChanged event) {
        roomChanged(event.roomId());
    }

    @TransactionalEventListener
    public void onRoomDeleted(RoomDeleted event) {
        Long roomId = event.roomId();
        template.convertAndSend("/topic/rooms/" + roomId + "/events", new RoomEvent("DELETED", null));
        template.convertAndSend("/topic/rooms", new RoomListEvent("DELETED", roomId, null));
    }

    @TransactionalEventListener
    public void onMessagePosted(MessagePosted event) {
        template.convertAndSend("/topic/rooms/" + event.message().roomId() + "/messages", event.message());
    }

    @TransactionalEventListener
    public void onUserKicked(UserKicked event) {
        template.convertAndSend("/topic/rooms/" + event.roomId() + "/events", new RoomEvent("KICKED", event.userId()));
    }

    /** 접속 상태 변화는 트랜잭션과 무관하게 바로 처리 */
    @EventListener
    @Transactional(readOnly = true)
    public void onPresenceChanged(PresenceChanged event) {
        event.roomIds().forEach(this::roomChanged);
    }

    public void typing(Long roomId, TypingEvent event) {
        template.convertAndSend("/topic/rooms/" + roomId + "/typing", event);
    }

    public void error(String userId, String message) {
        template.convertAndSendToUser(userId, "/queue/errors", new ErrorMessage(message));
    }

    private void roomChanged(Long roomId) {
        query.summary(roomId).ifPresent(summary -> {
            template.convertAndSend("/topic/rooms", new RoomListEvent("UPDATED", roomId, summary));
            template.convertAndSend("/topic/rooms/" + roomId + "/members", query.members(roomId));
        });
    }
}
