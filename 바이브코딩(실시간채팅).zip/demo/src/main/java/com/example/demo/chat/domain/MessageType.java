package com.example.demo.chat.domain;

public enum MessageType {
    /** 사용자가 보낸 대화 */
    TALK,
    /** 입장·퇴장·방장 변경 등 시스템 안내 */
    SYSTEM
}
