package com.example.demo.chat.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

import java.time.LocalDateTime;

/** 방 멤버: 입장한 뒤 나가기를 하지 않은 사용자 */
@Entity
@Table(name = "room_member",
        uniqueConstraints = @UniqueConstraint(name = "uk_room_member", columnNames = {"room_id", "user_id"}))
public class RoomMember {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "room_id", nullable = false)
    private Long roomId;

    @Column(name = "user_id", nullable = false, length = 36)
    private String userId;

    @Column(name = "joined_at", nullable = false)
    private LocalDateTime joinedAt;

    /** 마지막으로 읽은 메시지 id (읽음 표시 계산용) */
    @Column(name = "last_read_message_id", nullable = false)
    private long lastReadMessageId;

    protected RoomMember() {
    }

    public RoomMember(Long roomId, String userId, long lastReadMessageId) {
        this.roomId = roomId;
        this.userId = userId;
        this.lastReadMessageId = lastReadMessageId;
        this.joinedAt = LocalDateTime.now();
    }

    /** 앞으로만 이동. 바뀌었으면 true */
    public boolean readUpTo(long messageId) {
        if (messageId > lastReadMessageId) {
            lastReadMessageId = messageId;
            return true;
        }
        return false;
    }

    public Long getId() {
        return id;
    }

    public Long getRoomId() {
        return roomId;
    }

    public String getUserId() {
        return userId;
    }

    public LocalDateTime getJoinedAt() {
        return joinedAt;
    }

    public long getLastReadMessageId() {
        return lastReadMessageId;
    }
}
