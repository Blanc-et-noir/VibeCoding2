package com.example.demo.chat.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "chat_message", indexes = @Index(name = "idx_chat_message_room", columnList = "room_id, id"))
public class ChatMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "room_id", nullable = false)
    private Long roomId;

    @Enumerated(EnumType.STRING)
    @Column(name = "message_type", nullable = false, length = 10)
    private MessageType messageType;

    /** SYSTEM 메시지는 null */
    @Column(name = "sender_id", length = 36)
    private String senderId;

    /** 보낸 시점의 닉네임 */
    @Column(name = "sender_nickname", length = 20)
    private String senderNickname;

    @Column(name = "content", nullable = false, length = 1000)
    private String content;

    @Column(name = "sent_at", nullable = false)
    private LocalDateTime sentAt;

    protected ChatMessage() {
    }

    private ChatMessage(Long roomId, MessageType messageType, String senderId, String senderNickname, String content) {
        this.roomId = roomId;
        this.messageType = messageType;
        this.senderId = senderId;
        this.senderNickname = senderNickname;
        this.content = content;
        this.sentAt = LocalDateTime.now();
    }

    public static ChatMessage talk(Long roomId, AppUser sender, String content) {
        return new ChatMessage(roomId, MessageType.TALK, sender.getId(), sender.getNickname(), content);
    }

    public static ChatMessage system(Long roomId, String content) {
        return new ChatMessage(roomId, MessageType.SYSTEM, null, null, content);
    }

    public Long getId() {
        return id;
    }

    public Long getRoomId() {
        return roomId;
    }

    public MessageType getMessageType() {
        return messageType;
    }

    public String getSenderId() {
        return senderId;
    }

    public String getSenderNickname() {
        return senderNickname;
    }

    public String getContent() {
        return content;
    }

    public LocalDateTime getSentAt() {
        return sentAt;
    }
}
