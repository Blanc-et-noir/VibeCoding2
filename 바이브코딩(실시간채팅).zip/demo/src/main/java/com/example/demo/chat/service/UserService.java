package com.example.demo.chat.service;

import com.example.demo.chat.domain.AppUser;
import com.example.demo.chat.dto.ChatDtos.UserResponse;
import com.example.demo.chat.event.ChatEvents.RoomChanged;
import com.example.demo.chat.repository.AppUserRepository;
import com.example.demo.chat.repository.RoomMemberRepository;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

@Service
@Transactional
public class UserService {

    /** USR-03: 2~20자, 한글·영문·숫자 */
    private static final Pattern NICKNAME = Pattern.compile("^[가-힣a-zA-Z0-9]{2,20}$");

    private final AppUserRepository userRepository;
    private final RoomMemberRepository memberRepository;
    private final PresenceService presence;
    private final ApplicationEventPublisher events;

    public UserService(AppUserRepository userRepository, RoomMemberRepository memberRepository,
                       PresenceService presence, ApplicationEventPublisher events) {
        this.userRepository = userRepository;
        this.memberRepository = memberRepository;
        this.presence = presence;
        this.events = events;
    }

    /**
     * 입장(로그인). userId가 있으면 기존 사용자로 재입장(새로고침, 닉네임 변경),
     * 없거나 모르는 id면 새 사용자 발급.
     */
    public UserResponse login(String userId, String rawNickname) {
        String nickname = validateNickname(rawNickname);
        Optional<AppUser> existing = (userId == null || userId.isBlank())
                ? Optional.empty()
                : userRepository.findById(userId);

        // USR-04: 접속 중인 다른 사람과 닉네임 중복 금지
        String selfId = existing.map(AppUser::getId).orElse("");
        Set<String> online = presence.onlineUserIds();
        if (!online.isEmpty() && userRepository.existsByIdInAndNicknameAndIdNot(online, nickname, selfId)) {
            throw ChatException.conflict("이미 접속 중인 닉네임입니다. 다른 닉네임을 입력해 주세요.");
        }

        AppUser user;
        if (existing.isPresent()) {
            user = existing.get();
            if (!user.getNickname().equals(nickname)) {
                user.changeNickname(nickname);
                // 참여자 목록에 새 닉네임 반영
                memberRepository.findByUserId(user.getId())
                        .forEach(m -> events.publishEvent(new RoomChanged(m.getRoomId())));
            }
        } else {
            user = userRepository.save(new AppUser(UUID.randomUUID().toString(), nickname));
        }

        presence.markLoginPending(user.getId());
        return new UserResponse(user.getId(), user.getNickname());
    }

    @Transactional(readOnly = true)
    public AppUser requireUser(String userId) {
        if (userId == null || userId.isBlank()) {
            throw ChatException.unauthorized();
        }
        return userRepository.findById(userId).orElseThrow(ChatException::unauthorized);
    }

    public void logout(String userId) {
        presence.forceOffline(userId);
    }

    private static String validateNickname(String raw) {
        String nickname = raw == null ? "" : raw.strip();
        if (!NICKNAME.matcher(nickname).matches()) {
            throw ChatException.badRequest("닉네임은 한글·영문·숫자로 2~20자까지 입력할 수 있습니다.");
        }
        return nickname;
    }
}
