package com.example.demo.chat.web;

import com.example.demo.chat.dto.ChatDtos.ErrorMessage;
import com.example.demo.chat.service.ChatException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

/** REST 오류를 {"message": "..."} 형태로 통일 */
@RestControllerAdvice(assignableTypes = {RoomController.class, UserController.class})
public class ApiExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(ApiExceptionHandler.class);

    @ExceptionHandler(ChatException.class)
    public ResponseEntity<ErrorMessage> chat(ChatException e) {
        return ResponseEntity.status(e.getStatus()).body(new ErrorMessage(e.getMessage()));
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    public ResponseEntity<ErrorMessage> missingUser(MissingRequestHeaderException e) {
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new ErrorMessage("다시 로그인해 주세요."));
    }

    @ExceptionHandler({HttpMessageNotReadableException.class, MethodArgumentTypeMismatchException.class})
    public ResponseEntity<ErrorMessage> badRequest(Exception e) {
        return ResponseEntity.badRequest().body(new ErrorMessage("요청 형식이 올바르지 않습니다."));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorMessage> unexpected(Exception e) {
        log.error("API 처리 중 오류", e);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ErrorMessage("처리 중 오류가 발생했습니다."));
    }
}
