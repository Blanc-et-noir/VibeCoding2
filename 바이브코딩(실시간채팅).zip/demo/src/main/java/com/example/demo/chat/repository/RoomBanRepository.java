package com.example.demo.chat.repository;

import com.example.demo.chat.domain.RoomBan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface RoomBanRepository extends JpaRepository<RoomBan, Long> {

    boolean existsByRoomIdAndUserId(Long roomId, String userId);

    @Modifying(flushAutomatically = true)
    @Query("delete from RoomBan b where b.roomId = :roomId")
    void deleteAllInRoom(@Param("roomId") Long roomId);
}
