package com.example.demo.chat.event;

import com.example.demo.chat.dto.ChatDtos.MessageDto;

import java.util.Set;

/**
 * 서비스 → 브로드캐스터로 전달하는 내부 이벤트.
 * DB 변경 이벤트는 트랜잭션 커밋 후에 전송된다 (ChatBroadcaster 참고).
 */
public final class ChatEvents {

    private ChatEvents() {
    }

    public record RoomCreated(Long roomId) {
    }

    /** 방 정보·멤버·읽음 상태가 바뀜 → 방 목록과 참여자 목록 갱신 */
    public record RoomChanged(Long roomId) {
    }

    public record RoomDeleted(Long roomId) {
    }

    public record MessagePosted(MessageDto message) {
    }

    public record UserKicked(Long roomId, String userId) {
    }

    /** 방 화면을 보는 사람이 바뀜 (DB 변경 없음) */
    public record PresenceChanged(Set<Long> roomIds) {
    }
}
