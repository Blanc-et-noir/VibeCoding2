package com.example.demo.chat.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "chat_room")
public class ChatRoom {

    public static final int DEFAULT_CAPACITY = 50;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "name", nullable = false, length = 30)
    private String name;

    @Column(name = "owner_id", nullable = false, length = 36)
    private String ownerId;

    @Column(name = "capacity", nullable = false)
    private int capacity;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;

    @Column(name = "last_message_at")
    private LocalDateTime lastMessageAt;

    protected ChatRoom() {
    }

    public ChatRoom(String name, String ownerId) {
        this.name = name;
        this.ownerId = ownerId;
        this.capacity = DEFAULT_CAPACITY;
        this.createdAt = LocalDateTime.now();
    }

    public void rename(String name) {
        this.name = name;
    }

    public void changeOwner(String ownerId) {
        this.ownerId = ownerId;
    }

    public void touchLastMessage(LocalDateTime time) {
        this.lastMessageAt = time;
    }

    public boolean isOwner(String userId) {
        return ownerId.equals(userId);
    }

    /** 정렬 기준: 마지막 메시지 시각, 없으면 생성 시각 */
    public LocalDateTime getActivityAt() {
        return lastMessageAt != null ? lastMessageAt : createdAt;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public int getCapacity() {
        return capacity;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getLastMessageAt() {
        return lastMessageAt;
    }
}
