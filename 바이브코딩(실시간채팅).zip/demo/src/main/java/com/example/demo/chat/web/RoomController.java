package com.example.demo.chat.web;

import com.example.demo.chat.dto.ChatDtos.MessagePage;
import com.example.demo.chat.dto.ChatDtos.RoomDetail;
import com.example.demo.chat.dto.ChatDtos.RoomListItem;
import com.example.demo.chat.dto.ChatDtos.RoomNameRequest;
import com.example.demo.chat.dto.ChatDtos.TargetUserRequest;
import com.example.demo.chat.service.ChatException;
import com.example.demo.chat.service.ChatQueryService;
import com.example.demo.chat.service.RoomService;
import com.example.demo.chat.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 모든 요청에 X-User-Id 헤더 필요 (로그인 응답의 userId)
 *
 *  GET    /api/rooms                         방 목록 (안 읽은 수 포함)
 *  POST   /api/rooms             {name}      방 만들기
 *  GET    /api/rooms/{id}                    방 정보 + 참여자 (멤버만)
 *  PATCH  /api/rooms/{id}        {name}      방 이름 변경 (방장)
 *  DELETE /api/rooms/{id}                    방 삭제 (방장)
 *  POST   /api/rooms/{id}/join               입장
 *  POST   /api/rooms/{id}/leave              나가기
 *  POST   /api/rooms/{id}/kick   {userId}    강제 퇴장 (방장)
 *  POST   /api/rooms/{id}/owner  {userId}    방장 위임 (방장)
 *  GET    /api/rooms/{id}/messages?before=&after=   메시지 조회 (멤버만)
 */
@RestController
@RequestMapping("/api/rooms")
public class RoomController {

    public static final String USER_HEADER = "X-User-Id";

    private final RoomService roomService;
    private final ChatQueryService query;
    private final UserService userService;

    public RoomController(RoomService roomService, ChatQueryService query, UserService userService) {
        this.roomService = roomService;
        this.query = query;
        this.userService = userService;
    }

    @GetMapping
    public List<RoomListItem> rooms(@RequestHeader(USER_HEADER) String userId) {
        userService.requireUser(userId);
        return query.roomList(userId);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public RoomDetail create(@RequestHeader(USER_HEADER) String userId, @RequestBody RoomNameRequest request) {
        userService.requireUser(userId);
        Long roomId = roomService.create(userId, request.name());
        return query.detail(roomId);
    }

    @GetMapping("/{roomId}")
    public RoomDetail detail(@RequestHeader(USER_HEADER) String userId, @PathVariable Long roomId) {
        requireMember(userId, roomId);
        return query.detail(roomId);
    }

    @PatchMapping("/{roomId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void rename(@RequestHeader(USER_HEADER) String userId, @PathVariable Long roomId,
                       @RequestBody RoomNameRequest request) {
        userService.requireUser(userId);
        roomService.rename(roomId, userId, request.name());
    }

    @DeleteMapping("/{roomId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@RequestHeader(USER_HEADER) String userId, @PathVariable Long roomId) {
        userService.requireUser(userId);
        roomService.delete(roomId, userId);
    }

    @PostMapping("/{roomId}/join")
    public RoomDetail join(@RequestHeader(USER_HEADER) String userId, @PathVariable Long roomId) {
        userService.requireUser(userId);
        roomService.join(roomId, userId);
        return query.detail(roomId);
    }

    @PostMapping("/{roomId}/leave")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void leave(@RequestHeader(USER_HEADER) String userId, @PathVariable Long roomId) {
        userService.requireUser(userId);
        roomService.leave(roomId, userId);
    }

    @PostMapping("/{roomId}/kick")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void kick(@RequestHeader(USER_HEADER) String userId, @PathVariable Long roomId,
                     @RequestBody TargetUserRequest request) {
        userService.requireUser(userId);
        roomService.kick(roomId, userId, request.userId());
    }

    @PostMapping("/{roomId}/owner")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void transferOwner(@RequestHeader(USER_HEADER) String userId, @PathVariable Long roomId,
                              @RequestBody TargetUserRequest request) {
        userService.requireUser(userId);
        roomService.transferOwner(roomId, userId, request.userId());
    }

    @GetMapping("/{roomId}/messages")
    public MessagePage messages(@RequestHeader(USER_HEADER) String userId, @PathVariable Long roomId,
                                @RequestParam(required = false) Long before,
                                @RequestParam(required = false) Long after) {
        requireMember(userId, roomId);
        return query.messages(roomId, before, after);
    }

    private void requireMember(String userId, Long roomId) {
        userService.requireUser(userId);
        if (!query.isMember(roomId, userId)) {
            throw ChatException.forbidden("이 방의 멤버가 아닙니다.");
        }
    }
}
