package com.example.demo.chat.service;

import com.example.demo.chat.domain.AppUser;
import com.example.demo.chat.domain.ChatMessage;
import com.example.demo.chat.domain.ChatRoom;
import com.example.demo.chat.domain.MessageType;
import com.example.demo.chat.domain.RoomMember;
import com.example.demo.chat.dto.ChatDtos;
import com.example.demo.chat.dto.ChatDtos.MemberView;
import com.example.demo.chat.dto.ChatDtos.MessageDto;
import com.example.demo.chat.dto.ChatDtos.MessagePage;
import com.example.demo.chat.dto.ChatDtos.RoomDetail;
import com.example.demo.chat.dto.ChatDtos.RoomListItem;
import com.example.demo.chat.dto.ChatDtos.RoomSummary;
import com.example.demo.chat.repository.AppUserRepository;
import com.example.demo.chat.repository.ChatMessageRepository;
import com.example.demo.chat.repository.ChatRoomRepository;
import com.example.demo.chat.repository.RoomMemberRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/** 조회 전용 서비스 (화면 응답과 브로드캐스트에 공통으로 사용) */
@Service
@Transactional(readOnly = true)
public class ChatQueryService {

    private final ChatRoomRepository roomRepository;
    private final RoomMemberRepository memberRepository;
    private final ChatMessageRepository messageRepository;
    private final AppUserRepository userRepository;
    private final PresenceService presence;

    public ChatQueryService(ChatRoomRepository roomRepository, RoomMemberRepository memberRepository,
                            ChatMessageRepository messageRepository, AppUserRepository userRepository,
                            PresenceService presence) {
        this.roomRepository = roomRepository;
        this.memberRepository = memberRepository;
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
        this.presence = presence;
    }

    public boolean isMember(Long roomId, String userId) {
        return memberRepository.existsByRoomIdAndUserId(roomId, userId);
    }

    public String nickname(String userId) {
        return userRepository.findById(userId).map(AppUser::getNickname).orElse("알 수 없음");
    }

    public Optional<RoomSummary> summary(Long roomId) {
        return roomRepository.findById(roomId).map(this::toSummary);
    }

    /** 방 목록: 최근 대화가 있는 방이 위로 */
    public List<RoomListItem> roomList(String userId) {
        return roomRepository.findAll().stream()
                .sorted(Comparator.comparing(ChatRoom::getActivityAt).reversed())
                .map(room -> toListItem(room, userId))
                .toList();
    }

    public RoomListItem roomListItem(Long roomId, String userId) {
        return toListItem(requireRoom(roomId), userId);
    }

    public RoomDetail detail(Long roomId) {
        ChatRoom room = requireRoom(roomId);
        return new RoomDetail(toSummary(room), members(room));
    }

    public List<MemberView> members(Long roomId) {
        return roomRepository.findById(roomId).map(this::members).orElse(List.of());
    }

    public MessagePage messages(Long roomId, Long beforeId, Long afterId) {
        if (afterId != null) {
            List<MessageDto> after = messageRepository.findTop500ByRoomIdAndIdGreaterThanOrderByIdAsc(roomId, afterId)
                    .stream().map(MessageDto::from).toList();
            return new MessagePage(after, false);
        }

        List<ChatMessage> desc = beforeId == null
                ? messageRepository.findTop50ByRoomIdOrderByIdDesc(roomId)
                : messageRepository.findTop50ByRoomIdAndIdLessThanOrderByIdDesc(roomId, beforeId);
        List<ChatMessage> asc = new ArrayList<>(desc);
        Collections.reverse(asc);

        boolean hasMore = !asc.isEmpty() && messageRepository.existsByRoomIdAndIdLessThan(roomId, asc.get(0).getId());
        return new MessagePage(asc.stream().map(MessageDto::from).toList(), hasMore);
    }

    // ------------------------------------------------------------------

    private ChatRoom requireRoom(Long roomId) {
        return roomRepository.findById(roomId)
                .orElseThrow(() -> ChatException.notFound("존재하지 않는 채팅방입니다."));
    }

    private RoomListItem toListItem(ChatRoom room, String userId) {
        Optional<RoomMember> me = memberRepository.findByRoomIdAndUserId(room.getId(), userId);
        long unread = me.map(m -> messageRepository.countByRoomIdAndIdGreaterThanAndMessageTypeAndSenderIdNot(
                room.getId(), m.getLastReadMessageId(), MessageType.TALK, userId)).orElse(0L);
        return new RoomListItem(toSummary(room), me.isPresent(), unread);
    }

    private RoomSummary toSummary(ChatRoom room) {
        List<RoomMember> members = memberRepository.findByRoomIdOrderByIdAsc(room.getId());
        Set<String> viewers = presence.viewers(room.getId());
        long participants = members.stream().filter(m -> viewers.contains(m.getUserId())).count();
        Optional<ChatMessage> last = messageRepository.findTopByRoomIdOrderByIdDesc(room.getId());

        return new RoomSummary(
                room.getId(),
                room.getName(),
                room.getOwnerId(),
                nickname(room.getOwnerId()),
                members.size(),
                participants,
                room.getCapacity(),
                last.map(ChatMessage::getId).orElse(null),
                last.map(m -> m.getMessageType().name()).orElse(null),
                last.map(ChatMessage::getSenderId).orElse(null),
                ChatDtos.format(room.getLastMessageAt()),
                ChatDtos.format(room.getCreatedAt()));
    }

    private List<MemberView> members(ChatRoom room) {
        List<RoomMember> members = memberRepository.findByRoomIdOrderByIdAsc(room.getId());
        Map<String, String> nicknames = userRepository.findAllById(
                        members.stream().map(RoomMember::getUserId).toList()).stream()
                .collect(Collectors.toMap(AppUser::getId, AppUser::getNickname));
        Set<String> viewers = presence.viewers(room.getId());

        return members.stream()
                .map(m -> new MemberView(
                        m.getUserId(),
                        nicknames.getOrDefault(m.getUserId(), "알 수 없음"),
                        room.isOwner(m.getUserId()),
                        viewers.contains(m.getUserId()),
                        m.getLastReadMessageId()))
                .sorted(Comparator.comparing(MemberView::owner).reversed()
                        .thenComparing(Comparator.comparing(MemberView::inRoom).reversed()))
                .collect(Collectors.toList());
    }
}
