package com.example.demo.chat.repository;

import com.example.demo.chat.domain.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;

public interface AppUserRepository extends JpaRepository<AppUser, String> {

    /** 주어진 사용자들(접속 중) 가운데 같은 닉네임을 쓰는 다른 사람이 있는지 */
    boolean existsByIdInAndNicknameAndIdNot(Collection<String> ids, String nickname, String excludeId);
}
