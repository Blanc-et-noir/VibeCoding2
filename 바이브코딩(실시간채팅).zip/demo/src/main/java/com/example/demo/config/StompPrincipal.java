package com.example.demo.config;

import java.security.Principal;

/** STOMP 세션의 사용자. name = userId */
public record StompPrincipal(String userId) implements Principal {

    @Override
    public String getName() {
        return userId;
    }
}
