package com.example.demo.chat.service;

import com.example.demo.chat.domain.AppUser;
import com.example.demo.chat.domain.ChatMessage;
import com.example.demo.chat.domain.ChatRoom;
import com.example.demo.chat.domain.RoomBan;
import com.example.demo.chat.domain.RoomMember;
import com.example.demo.chat.event.ChatEvents.RoomChanged;
import com.example.demo.chat.event.ChatEvents.RoomCreated;
import com.example.demo.chat.event.ChatEvents.RoomDeleted;
import com.example.demo.chat.event.ChatEvents.UserKicked;
import com.example.demo.chat.repository.AppUserRepository;
import com.example.demo.chat.repository.ChatMessageRepository;
import com.example.demo.chat.repository.ChatRoomRepository;
import com.example.demo.chat.repository.RoomBanRepository;
import com.example.demo.chat.repository.RoomMemberRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class RoomService {

    private static final Logger log = LoggerFactory.getLogger(RoomService.class);
    private static final int ROOM_NAME_MAX = 30;

    private final ChatRoomRepository roomRepository;
    private final RoomMemberRepository memberRepository;
    private final RoomBanRepository banRepository;
    private final ChatMessageRepository messageRepository;
    private final AppUserRepository userRepository;
    private final MessageService messageService;
    private final PresenceService presence;
    private final ApplicationEventPublisher events;

    public RoomService(ChatRoomRepository roomRepository, RoomMemberRepository memberRepository,
                       RoomBanRepository banRepository, ChatMessageRepository messageRepository,
                       AppUserRepository userRepository, MessageService messageService,
                       PresenceService presence, ApplicationEventPublisher events) {
        this.roomRepository = roomRepository;
        this.memberRepository = memberRepository;
        this.banRepository = banRepository;
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
        this.messageService = messageService;
        this.presence = presence;
        this.events = events;
    }

    /** ROOM-03: 만든 사람이 방장이자 첫 멤버 */
    public Long create(String userId, String rawName) {
        String name = validateName(rawName);
        AppUser owner = requireUser(userId);

        ChatRoom room = roomRepository.save(new ChatRoom(name, owner.getId()));
        memberRepository.save(new RoomMember(room.getId(), owner.getId(), 0L));
        messageService.postSystem(room, owner.getNickname() + "님이 방을 만들었습니다.");

        log.info("방 생성: {} ({}) by {}", room.getName(), room.getId(), owner.getNickname());
        events.publishEvent(new RoomCreated(room.getId()));
        return room.getId();
    }

    /** ROOM-04: 입장. 이미 멤버면 아무것도 하지 않음 */
    public void join(Long roomId, String userId) {
        ChatRoom room = requireRoom(roomId);
        if (memberRepository.existsByRoomIdAndUserId(roomId, userId)) {
            return;
        }
        if (banRepository.existsByRoomIdAndUserId(roomId, userId)) {
            throw ChatException.forbidden("이 방에서 내보내져 다시 들어갈 수 없습니다.");
        }
        if (memberRepository.countByRoomId(roomId) >= room.getCapacity()) {
            throw ChatException.conflict("방 정원(" + room.getCapacity() + "명)이 가득 찼습니다.");
        }

        AppUser user = requireUser(userId);
        long latest = messageRepository.findTopByRoomIdOrderByIdDesc(roomId).map(ChatMessage::getId).orElse(0L);
        memberRepository.save(new RoomMember(roomId, userId, latest));
        messageService.postSystem(room, user.getNickname() + "님이 입장했습니다.");

        log.info("입장: {} → 방 {}", user.getNickname(), roomId);
        events.publishEvent(new RoomChanged(roomId));
    }

    /** ROOM-05, ROOM-13: 나가기. 방장이면 다음 멤버에게 위임, 아무도 없으면 방 삭제 */
    public void leave(Long roomId, String userId) {
        ChatRoom room = requireRoom(roomId);
        RoomMember member = requireMember(roomId, userId);
        AppUser user = requireUser(userId);

        memberRepository.delete(member);
        memberRepository.flush();
        presence.removeFromRoom(userId, roomId);

        List<RoomMember> remaining = memberRepository.findByRoomIdOrderByIdAsc(roomId);
        if (remaining.isEmpty()) {
            log.info("마지막 멤버 퇴장으로 방 삭제: {}", roomId);
            deleteRoom(room);
            return;
        }

        messageService.postSystem(room, user.getNickname() + "님이 퇴장했습니다.");
        if (room.isOwner(userId)) {
            String nextOwner = remaining.get(0).getUserId();
            room.changeOwner(nextOwner);
            messageService.postSystem(room, requireUser(nextOwner).getNickname() + "님이 방장이 되었습니다.");
        }

        log.info("퇴장: {} ← 방 {}", user.getNickname(), roomId);
        events.publishEvent(new RoomChanged(roomId));
    }

    /** ROOM-10 */
    public void rename(Long roomId, String userId, String rawName) {
        ChatRoom room = requireOwner(roomId, userId);
        String name = validateName(rawName);
        if (name.equals(room.getName())) {
            return;
        }
        room.rename(name);
        messageService.postSystem(room, "방 이름이 '" + name + "'(으)로 바뀌었습니다.");
        events.publishEvent(new RoomChanged(roomId));
    }

    /** ROOM-09 */
    public void delete(Long roomId, String userId) {
        ChatRoom room = requireOwner(roomId, userId);
        log.info("방 삭제: {} ({})", room.getName(), roomId);
        deleteRoom(room);
    }

    /** ROOM-11: 강제 퇴장 + 재입장 차단 */
    public void kick(Long roomId, String ownerId, String targetId) {
        ChatRoom room = requireOwner(roomId, ownerId);
        if (ownerId.equals(targetId)) {
            throw ChatException.badRequest("자기 자신은 내보낼 수 없습니다.");
        }
        RoomMember target = requireMember(roomId, targetId);
        AppUser targetUser = requireUser(targetId);

        memberRepository.delete(target);
        if (!banRepository.existsByRoomIdAndUserId(roomId, targetId)) {
            banRepository.save(new RoomBan(roomId, targetId));
        }
        presence.removeFromRoom(targetId, roomId);
        messageService.postSystem(room, targetUser.getNickname() + "님이 내보내졌습니다.");

        log.info("강제 퇴장: {} ← 방 {}", targetUser.getNickname(), roomId);
        events.publishEvent(new UserKicked(roomId, targetId));
        events.publishEvent(new RoomChanged(roomId));
    }

    /** ROOM-12 */
    public void transferOwner(Long roomId, String ownerId, String targetId) {
        ChatRoom room = requireOwner(roomId, ownerId);
        if (ownerId.equals(targetId)) {
            return;
        }
        requireMember(roomId, targetId);
        room.changeOwner(targetId);
        messageService.postSystem(room, requireUser(targetId).getNickname() + "님이 방장이 되었습니다.");
        events.publishEvent(new RoomChanged(roomId));
    }

    // ------------------------------------------------------------------

    private void deleteRoom(ChatRoom room) {
        Long roomId = room.getId();
        messageRepository.deleteAllInRoom(roomId);
        memberRepository.deleteAllInRoom(roomId);
        banRepository.deleteAllInRoom(roomId);
        roomRepository.delete(room);
        events.publishEvent(new RoomDeleted(roomId));
    }

    private ChatRoom requireRoom(Long roomId) {
        return roomRepository.findById(roomId)
                .orElseThrow(() -> ChatException.notFound("존재하지 않는 채팅방입니다."));
    }

    private ChatRoom requireOwner(Long roomId, String userId) {
        ChatRoom room = requireRoom(roomId);
        if (!room.isOwner(userId)) {
            throw ChatException.forbidden("방장만 할 수 있습니다.");
        }
        return room;
    }

    private RoomMember requireMember(Long roomId, String userId) {
        return memberRepository.findByRoomIdAndUserId(roomId, userId)
                .orElseThrow(() -> ChatException.notFound("이 방의 멤버가 아닙니다."));
    }

    private AppUser requireUser(String userId) {
        return userRepository.findById(userId).orElseThrow(ChatException::unauthorized);
    }

    private static String validateName(String raw) {
        String name = raw == null ? "" : raw.strip();
        if (name.isEmpty()) {
            throw ChatException.badRequest("방 이름을 입력해 주세요.");
        }
        if (name.length() > ROOM_NAME_MAX) {
            throw ChatException.badRequest("방 이름은 " + ROOM_NAME_MAX + "자까지 입력할 수 있습니다.");
        }
        return name;
    }
}
