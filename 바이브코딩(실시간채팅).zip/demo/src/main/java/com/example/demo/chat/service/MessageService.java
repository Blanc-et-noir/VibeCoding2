package com.example.demo.chat.service;

import com.example.demo.chat.domain.AppUser;
import com.example.demo.chat.domain.ChatMessage;
import com.example.demo.chat.domain.ChatRoom;
import com.example.demo.chat.domain.RoomMember;
import com.example.demo.chat.dto.ChatDtos.MessageDto;
import com.example.demo.chat.event.ChatEvents.MessagePosted;
import com.example.demo.chat.event.ChatEvents.RoomChanged;
import com.example.demo.chat.repository.AppUserRepository;
import com.example.demo.chat.repository.ChatMessageRepository;
import com.example.demo.chat.repository.ChatRoomRepository;
import com.example.demo.chat.repository.RoomMemberRepository;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class MessageService {

    private static final int CONTENT_MAX = 1000;

    private final ChatRoomRepository roomRepository;
    private final RoomMemberRepository memberRepository;
    private final ChatMessageRepository messageRepository;
    private final AppUserRepository userRepository;
    private final ApplicationEventPublisher events;

    public MessageService(ChatRoomRepository roomRepository, RoomMemberRepository memberRepository,
                          ChatMessageRepository messageRepository, AppUserRepository userRepository,
                          ApplicationEventPublisher events) {
        this.roomRepository = roomRepository;
        this.memberRepository = memberRepository;
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
        this.events = events;
    }

    /** MSG-01: 대화 전송. 보낸 사람은 자기 메시지를 읽은 것으로 처리 */
    public void send(Long roomId, String userId, String rawContent) {
        String content = rawContent == null ? "" : rawContent.strip();
        if (content.isEmpty()) {
            throw ChatException.badRequest("메시지를 입력해 주세요.");
        }
        if (content.length() > CONTENT_MAX) {
            throw ChatException.badRequest("메시지는 " + CONTENT_MAX + "자까지 보낼 수 있습니다.");
        }

        ChatRoom room = roomRepository.findById(roomId)
                .orElseThrow(() -> ChatException.notFound("존재하지 않는 채팅방입니다."));
        RoomMember member = memberRepository.findByRoomIdAndUserId(roomId, userId)
                .orElseThrow(() -> ChatException.forbidden("이 방의 멤버가 아닙니다."));
        AppUser sender = userRepository.findById(userId).orElseThrow(ChatException::unauthorized);

        ChatMessage saved = messageRepository.save(ChatMessage.talk(roomId, sender, content));
        room.touchLastMessage(saved.getSentAt());
        member.readUpTo(saved.getId());

        events.publishEvent(new MessagePosted(MessageDto.from(saved)));
        events.publishEvent(new RoomChanged(roomId));
    }

    /** MSG-05: 시스템 메시지 저장 + 전송 (호출한 쪽이 RoomChanged 를 발행) */
    public void postSystem(ChatRoom room, String content) {
        ChatMessage saved = messageRepository.save(ChatMessage.system(room.getId(), content));
        room.touchLastMessage(saved.getSentAt());
        events.publishEvent(new MessagePosted(MessageDto.from(saved)));
    }

    /** MSG-07: 읽음 처리. 실제로 앞으로 이동했을 때만 알림 */
    public void markRead(Long roomId, String userId, Long messageId) {
        if (messageId == null) {
            return;
        }
        RoomMember member = memberRepository.findByRoomIdAndUserId(roomId, userId).orElse(null);
        if (member == null) {
            return;
        }
        long latest = messageRepository.findTopByRoomIdOrderByIdDesc(roomId).map(ChatMessage::getId).orElse(0L);
        if (member.readUpTo(Math.min(messageId, latest))) {
            events.publishEvent(new RoomChanged(roomId));
        }
    }
}
