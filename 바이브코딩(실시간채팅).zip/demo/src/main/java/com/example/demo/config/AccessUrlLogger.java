package com.example.demo.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.web.server.context.WebServerApplicationContext;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.net.Inet4Address;
import java.net.NetworkInterface;
import java.util.Collections;

/** 서버가 뜨면 다른 PC에서 접속할 수 있는 주소를 로그에 출력 */
@Component
public class AccessUrlLogger {

    private static final Logger log = LoggerFactory.getLogger(AccessUrlLogger.class);

    @EventListener
    public void onReady(ApplicationReadyEvent event) throws Exception {
        int port = ((WebServerApplicationContext) event.getApplicationContext()).getWebServer().getPort();
        for (NetworkInterface nic : Collections.list(NetworkInterface.getNetworkInterfaces())) {
            if (!nic.isUp() || nic.isLoopback() || nic.isVirtual()) continue;
            Collections.list(nic.getInetAddresses()).stream()
                    .filter(a -> a instanceof Inet4Address)
                    .forEach(a -> log.info("접속 주소: http://{}:{}  ({})",
                            a.getHostAddress(), port, nic.getDisplayName()));
        }
    }
}