package com.example.demo.chat.service;

import com.example.demo.chat.event.ChatEvents.PresenceChanged;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * 접속 상태를 메모리에서 관리한다 (서버를 재시작하면 어차피 모두 끊기므로 DB에 두지 않음).
 *
 * - 접속 중: STOMP 세션이 하나라도 있는 사용자
 * - 방 참여자: 그 방 화면을 보고 있는 사용자
 * - 유예(CONN-04): 연결이 끊겨도 10초 동안은 접속 중·참여 중으로 본다.
 *   새로고침이나 잠깐의 끊김으로 참여자 목록이 깜빡이지 않게 하기 위함.
 */
@Service
public class PresenceService {

    private static final Logger log = LoggerFactory.getLogger(PresenceService.class);
    private static final Duration GRACE = Duration.ofSeconds(10);

    private record Viewer(Long roomId, String userId) {
    }

    private final ApplicationEventPublisher publisher;
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "presence-grace");
        t.setDaemon(true);
        return t;
    });

    // 아래 맵은 모두 this 로 동기화
    private final Map<String, String> sessionUser = new HashMap<>();   // sessionId → userId
    private final Map<String, Long> sessionRoom = new HashMap<>();     // sessionId → 보고 있는 방
    private final Map<String, Instant> graceUsers = new HashMap<>();   // userId → 유예 만료
    private final Map<Viewer, Instant> graceViewers = new HashMap<>(); // (방, 사용자) → 유예 만료

    public PresenceService(ApplicationEventPublisher publisher) {
        this.publisher = publisher;
    }

    public void connected(String sessionId, String userId) {
        synchronized (this) {
            sessionUser.put(sessionId, userId);
        }
    }

    public void disconnected(String sessionId) {
        Long room;
        synchronized (this) {
            String userId = sessionUser.remove(sessionId);
            room = sessionRoom.remove(sessionId);
            if (userId == null) {
                return;
            }
            Instant until = Instant.now().plus(GRACE);
            graceUsers.put(userId, until);
            if (room != null) {
                graceViewers.put(new Viewer(room, userId), until);
            }
        }
        if (room != null) {
            // 유예가 끝난 뒤 참여자 목록을 다시 계산해서 알린다
            Long roomId = room;
            scheduler.schedule(() -> safePublish(Set.of(roomId)),
                    GRACE.toMillis() + 500, TimeUnit.MILLISECONDS);
        }
    }

    /** 로그인 직후 STOMP 연결 전까지 닉네임을 잠시 점유 */
    public synchronized void markLoginPending(String userId) {
        graceUsers.put(userId, Instant.now().plus(GRACE));
    }

    public void enterRoom(String sessionId, String userId, Long roomId) {
        Long previous;
        synchronized (this) {
            sessionUser.putIfAbsent(sessionId, userId);
            previous = sessionRoom.put(sessionId, roomId);
            graceViewers.remove(new Viewer(roomId, userId));
        }
        Set<Long> changed = new HashSet<>();
        changed.add(roomId);
        if (previous != null && !previous.equals(roomId)) {
            changed.add(previous);
        }
        safePublish(changed);
    }

    public void exitRoom(String sessionId) {
        Long previous;
        synchronized (this) {
            previous = sessionRoom.remove(sessionId);
        }
        if (previous != null) {
            safePublish(Set.of(previous));
        }
    }

    /**
     * 특정 사용자를 한 방의 참여자에서 즉시 제외 (강제 퇴장, 나가기).
     * 트랜잭션 안에서 호출되므로 알림은 하지 않는다 — 호출한 쪽이 커밋 후 RoomChanged 로 알린다.
     */
    public synchronized void removeFromRoom(String userId, Long roomId) {
        sessionRoom.entrySet().removeIf(e ->
                roomId.equals(e.getValue()) && userId.equals(sessionUser.get(e.getKey())));
        graceViewers.remove(new Viewer(roomId, userId));
    }

    /** 로그아웃: 유예 없이 바로 접속 종료로 처리 */
    public void forceOffline(String userId) {
        Set<Long> changed = new HashSet<>();
        synchronized (this) {
            graceUsers.remove(userId);
            graceViewers.entrySet().removeIf(e -> {
                if (e.getKey().userId().equals(userId)) {
                    changed.add(e.getKey().roomId());
                    return true;
                }
                return false;
            });
            sessionRoom.entrySet().removeIf(e -> {
                if (userId.equals(sessionUser.get(e.getKey()))) {
                    changed.add(e.getValue());
                    return true;
                }
                return false;
            });
        }
        safePublish(changed);
    }

    /** 접속 중(유예 포함)인 사용자 */
    public synchronized Set<String> onlineUserIds() {
        Instant now = Instant.now();
        Set<String> result = new HashSet<>(sessionUser.values());
        graceUsers.entrySet().removeIf(e -> e.getValue().isBefore(now));
        result.addAll(graceUsers.keySet());
        return result;
    }

    /** 이 방 화면을 보고 있는 사용자 (유예 포함) */
    public synchronized Set<String> viewers(Long roomId) {
        Instant now = Instant.now();
        Set<String> result = new HashSet<>();
        sessionRoom.forEach((sessionId, room) -> {
            if (roomId.equals(room)) {
                String userId = sessionUser.get(sessionId);
                if (userId != null) {
                    result.add(userId);
                }
            }
        });
        graceViewers.entrySet().removeIf(e -> e.getValue().isBefore(now));
        graceViewers.keySet().forEach(v -> {
            if (v.roomId().equals(roomId)) {
                result.add(v.userId());
            }
        });
        return result;
    }

    private void safePublish(Set<Long> roomIds) {
        if (roomIds.isEmpty()) {
            return;
        }
        try {
            publisher.publishEvent(new PresenceChanged(Set.copyOf(roomIds)));
        } catch (RuntimeException e) {
            log.warn("접속 상태 알림 실패: {}", e.getMessage(), e);
        }
    }

    @PreDestroy
    void shutdown() {
        scheduler.shutdownNow();
    }
}
