package com.example.demo.chat.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

import java.time.LocalDateTime;

/** 강제 퇴장당해 다시 들어올 수 없는 사용자 */
@Entity
@Table(name = "room_ban",
        uniqueConstraints = @UniqueConstraint(name = "uk_room_ban", columnNames = {"room_id", "user_id"}))
public class RoomBan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "room_id", nullable = false)
    private Long roomId;

    @Column(name = "user_id", nullable = false, length = 36)
    private String userId;

    @Column(name = "banned_at", nullable = false)
    private LocalDateTime bannedAt;

    protected RoomBan() {
    }

    public RoomBan(Long roomId, String userId) {
        this.roomId = roomId;
        this.userId = userId;
        this.bannedAt = LocalDateTime.now();
    }

    public Long getId() {
        return id;
    }

    public Long getRoomId() {
        return roomId;
    }

    public String getUserId() {
        return userId;
    }
}
