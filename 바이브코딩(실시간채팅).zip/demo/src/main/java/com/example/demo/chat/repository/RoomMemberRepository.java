package com.example.demo.chat.repository;

import com.example.demo.chat.domain.RoomMember;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface RoomMemberRepository extends JpaRepository<RoomMember, Long> {

    /** 입장 순서대로 */
    List<RoomMember> findByRoomIdOrderByIdAsc(Long roomId);

    Optional<RoomMember> findByRoomIdAndUserId(Long roomId, String userId);

    boolean existsByRoomIdAndUserId(Long roomId, String userId);

    long countByRoomId(Long roomId);

    List<RoomMember> findByUserId(String userId);

    @Modifying(flushAutomatically = true)
    @Query("delete from RoomMember m where m.roomId = :roomId")
    void deleteAllInRoom(@Param("roomId") Long roomId);
}
