package com.example.demo.chat.repository;

import com.example.demo.chat.domain.ChatMessage;
import com.example.demo.chat.domain.MessageType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {

    /** 최근 50건 (최신순) */
    List<ChatMessage> findTop50ByRoomIdOrderByIdDesc(Long roomId);

    /** 특정 메시지보다 이전 50건 (최신순) — 이전 메시지 불러오기 */
    List<ChatMessage> findTop50ByRoomIdAndIdLessThanOrderByIdDesc(Long roomId, Long beforeId);

    /** 특정 메시지 이후 (오래된 순) — 재연결 시 놓친 메시지 보충 */
    List<ChatMessage> findTop500ByRoomIdAndIdGreaterThanOrderByIdAsc(Long roomId, Long afterId);

    boolean existsByRoomIdAndIdLessThan(Long roomId, Long id);

    Optional<ChatMessage> findTopByRoomIdOrderByIdDesc(Long roomId);

    /** 안 읽은 메시지 수 (다른 사람이 보낸 대화만) */
    long countByRoomIdAndIdGreaterThanAndMessageTypeAndSenderIdNot(
            Long roomId, Long afterId, MessageType messageType, String senderId);

    @Modifying(flushAutomatically = true)
    @Query("delete from ChatMessage m where m.roomId = :roomId")
    void deleteAllInRoom(@Param("roomId") Long roomId);
}
