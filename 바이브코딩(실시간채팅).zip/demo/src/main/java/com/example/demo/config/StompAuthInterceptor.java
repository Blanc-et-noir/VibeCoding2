package com.example.demo.config;

import com.example.demo.chat.repository.AppUserRepository;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessagingException;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.messaging.support.MessageHeaderAccessor;
import org.springframework.stereotype.Component;

/**
 * STOMP CONNECT 시 userId 헤더를 확인해 사용자(Principal)로 등록한다.
 * 이후 @MessageMapping 메서드에서는 Principal.getName() 으로 userId를 얻는다.
 * (테스트용 간이 인증: 비밀번호 없이 서버가 발급한 userId만 확인)
 */
@Component
public class StompAuthInterceptor implements ChannelInterceptor {

    private final AppUserRepository userRepository;

    public StompAuthInterceptor(AppUserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public Message<?> preSend(Message<?> message, MessageChannel channel) {
        StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);
        if (accessor != null && StompCommand.CONNECT.equals(accessor.getCommand())) {
            String userId = accessor.getFirstNativeHeader("userId");
            if (userId == null || !userRepository.existsById(userId)) {
                throw new MessagingException("UNAUTHORIZED");
            }
            accessor.setUser(new StompPrincipal(userId));
        }
        return message;
    }
}
