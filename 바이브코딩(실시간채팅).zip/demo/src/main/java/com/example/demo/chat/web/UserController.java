package com.example.demo.chat.web;

import com.example.demo.chat.dto.ChatDtos.LoginRequest;
import com.example.demo.chat.dto.ChatDtos.UserResponse;
import com.example.demo.chat.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

/**
 *  POST /api/users/login   {userId?, nickname}  입장(로그인), 닉네임 변경
 *  POST /api/users/logout                       로그아웃
 */
@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/login")
    public UserResponse login(@RequestBody LoginRequest request) {
        return userService.login(request.userId(), request.nickname());
    }

    @PostMapping("/logout")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void logout(@RequestHeader(value = RoomController.USER_HEADER, required = false) String userId) {
        if (userId != null && !userId.isBlank()) {
            userService.logout(userId);
        }
    }
}
