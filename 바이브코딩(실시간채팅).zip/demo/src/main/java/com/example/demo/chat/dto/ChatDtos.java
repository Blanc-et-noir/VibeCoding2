package com.example.demo.chat.dto;

import com.example.demo.chat.domain.ChatMessage;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 요청/응답 DTO 모음.
 * 날짜는 Jackson 버전별 직렬화 차이를 피하려고 "yyyy-MM-dd HH:mm:ss" 문자열로 내려준다.
 */
public final class ChatDtos {

    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private ChatDtos() {
    }

    public static String format(LocalDateTime time) {
        return time == null ? null : time.format(FORMAT);
    }

    // ---------- 요청 (REST) ----------

    public record LoginRequest(String userId, String nickname) {
    }

    public record RoomNameRequest(String name) {
    }

    public record TargetUserRequest(String userId) {
    }

    // ---------- 요청 (STOMP) ----------

    public record SendMessageRequest(String content) {
    }

    public record ReadRequest(Long messageId) {
    }

    public record TypingRequest(boolean typing) {
    }

    // ---------- 응답 ----------

    public record UserResponse(String userId, String nickname) {
    }

    /** 모든 사용자에게 같은 방 정보 */
    public record RoomSummary(
            Long id,
            String name,
            String ownerId,
            String ownerNickname,
            long memberCount,
            long participantCount,
            int capacity,
            Long lastMessageId,
            String lastMessageType,
            String lastMessageSenderId,
            String lastMessageAt,
            String createdAt) {
    }

    /** 방 목록 한 줄 (사용자별 정보 포함) */
    public record RoomListItem(RoomSummary room, boolean member, long unreadCount) {
    }

    /** 참여자 목록 한 줄. inRoom = 지금 이 방 화면을 보고 있는지 */
    public record MemberView(String userId, String nickname, boolean owner, boolean inRoom, long lastReadMessageId) {
    }

    public record RoomDetail(RoomSummary room, List<MemberView> members) {
    }

    public record MessageDto(Long id, Long roomId, String type, String senderId, String senderNickname,
                             String content, String sentAt) {

        public static MessageDto from(ChatMessage m) {
            return new MessageDto(m.getId(), m.getRoomId(), m.getMessageType().name(), m.getSenderId(),
                    m.getSenderNickname(), m.getContent(), format(m.getSentAt()));
        }
    }

    /** hasMore = 이보다 오래된 메시지가 더 있는지 */
    public record MessagePage(List<MessageDto> messages, boolean hasMore) {
    }

    // ---------- 브로드캐스트 ----------

    /** /topic/rooms — type: CREATED | UPDATED | DELETED */
    public record RoomListEvent(String type, Long roomId, RoomSummary room) {
    }

    /** /topic/rooms/{id}/events — type: DELETED | KICKED */
    public record RoomEvent(String type, String userId) {
    }

    /** /topic/rooms/{id}/typing */
    public record TypingEvent(String userId, String nickname, boolean typing) {
    }

    public record ErrorMessage(String message) {
    }
}
