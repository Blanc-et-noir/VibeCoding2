package com.example.demo.chat.service;

import org.springframework.http.HttpStatus;

/** 사용자에게 그대로 보여줄 메시지를 가진 예외 */
public class ChatException extends RuntimeException {

    private final HttpStatus status;

    public ChatException(HttpStatus status, String message) {
        super(message);
        this.status = status;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public static ChatException badRequest(String message) {
        return new ChatException(HttpStatus.BAD_REQUEST, message);
    }

    public static ChatException unauthorized() {
        return new ChatException(HttpStatus.UNAUTHORIZED, "다시 로그인해 주세요.");
    }

    public static ChatException forbidden(String message) {
        return new ChatException(HttpStatus.FORBIDDEN, message);
    }

    public static ChatException notFound(String message) {
        return new ChatException(HttpStatus.NOT_FOUND, message);
    }

    public static ChatException conflict(String message) {
        return new ChatException(HttpStatus.CONFLICT, message);
    }
}
