package com.example.demo.chat.web;

import com.example.demo.chat.dto.ChatDtos.ReadRequest;
import com.example.demo.chat.dto.ChatDtos.SendMessageRequest;
import com.example.demo.chat.dto.ChatDtos.TypingEvent;
import com.example.demo.chat.dto.ChatDtos.TypingRequest;
import com.example.demo.chat.service.ChatBroadcaster;
import com.example.demo.chat.service.ChatException;
import com.example.demo.chat.service.ChatQueryService;
import com.example.demo.chat.service.MessageService;
import com.example.demo.chat.service.PresenceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageExceptionHandler;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;

import java.security.Principal;

/**
 * STOMP 메시지 처리 (보낸 사람은 항상 연결 시 확인한 Principal 기준)
 *
 *  SEND /app/rooms/{roomId}/send    {content}     메시지 전송
 *  SEND /app/rooms/{roomId}/read    {messageId}   읽음 처리
 *  SEND /app/rooms/{roomId}/typing  {typing}      입력 중 알림
 *  SEND /app/rooms/{roomId}/enter   {}            방 화면 보기 시작 (참여자 표시)
 *  SEND /app/rooms/exit             {}            방 화면에서 벗어남
 */
@Controller
public class ChatStompController {

    private static final Logger log = LoggerFactory.getLogger(ChatStompController.class);

    private final MessageService messageService;
    private final ChatQueryService query;
    private final PresenceService presence;
    private final ChatBroadcaster broadcaster;

    public ChatStompController(MessageService messageService, ChatQueryService query,
                               PresenceService presence, ChatBroadcaster broadcaster) {
        this.messageService = messageService;
        this.query = query;
        this.presence = presence;
        this.broadcaster = broadcaster;
    }

    @MessageMapping("/rooms/{roomId}/send")
    public void send(@DestinationVariable Long roomId, @Payload SendMessageRequest request, Principal user) {
        messageService.send(roomId, user.getName(), request.content());
    }

    @MessageMapping("/rooms/{roomId}/read")
    public void read(@DestinationVariable Long roomId, @Payload ReadRequest request, Principal user) {
        messageService.markRead(roomId, user.getName(), request.messageId());
    }

    @MessageMapping("/rooms/{roomId}/typing")
    public void typing(@DestinationVariable Long roomId, @Payload TypingRequest request, Principal user) {
        String userId = user.getName();
        if (query.isMember(roomId, userId)) {
            broadcaster.typing(roomId, new TypingEvent(userId, query.nickname(userId), request.typing()));
        }
    }

    @MessageMapping("/rooms/{roomId}/enter")
    public void enter(@DestinationVariable Long roomId, Principal user, SimpMessageHeaderAccessor headers) {
        if (!query.isMember(roomId, user.getName())) {
            throw ChatException.forbidden("이 방의 멤버가 아닙니다.");
        }
        presence.enterRoom(headers.getSessionId(), user.getName(), roomId);
    }

    @MessageMapping("/rooms/exit")
    public void exit(SimpMessageHeaderAccessor headers) {
        presence.exitRoom(headers.getSessionId());
    }

    /** 오류는 보낸 사람에게만 /user/queue/errors 로 알린다 */
    @MessageExceptionHandler(ChatException.class)
    public void handleChatException(ChatException e, Principal user) {
        if (user != null) {
            broadcaster.error(user.getName(), e.getMessage());
        }
    }

    @MessageExceptionHandler(Exception.class)
    public void handleUnexpected(Exception e, Principal user) {
        log.error("STOMP 메시지 처리 중 오류", e);
        if (user != null) {
            broadcaster.error(user.getName(), "처리 중 오류가 발생했습니다.");
        }
    }
}
